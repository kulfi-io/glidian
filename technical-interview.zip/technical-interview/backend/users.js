/****************************************************************************************
 * ADD YOUR BACKEND ROUTES HERE  (they will be nested under `/users`)
 ****************************************************************************************/

const router = (module.exports = require("express").Router());
const { User, Group } = require("./db");

module.exports = router;

// Quick guide to endpoint definition:
//  * router.get("/something")                --> simple GET url
//  * router.get("/something/:myVariable")    --> dynamic GET url, myVariable available in `req.params` (as a *string*)
//  * router.post("/something")               --> simple POST url, body available as `req.body`
//  * query parameters ("/something?foo=bar") --> available in `req.query` (as a *string*)

router.get("/", async (req, res, next) => {
  try {
    const group = req.query.group ? req.query.group : undefined;

    let users;

    if (group) {
      users = await User.findAll({
        include: {
          model: Group,
          where: {
            id: group,
          },
        },
      });

      res.status(200).send(users);
    } else {
      users = await User.findAll({
        include: {
          model: Group,
        },
      });

      res.status(200).send(users);
    }
  } catch (error) {
    next(error);
  }
});

router.put("/activated", async (req, res, next) => {
  try {
    const data = Object.entries(req.body);

    for (let i = 0; i < data.length; i++) {
      await User.update(
        {
          isActivated: data[i][1].toString(),
        },
        { where: { id: data[i][0] } }
      );

    }

    res.status(200).send();
  } catch (error) {
    next(error);
  }
});
