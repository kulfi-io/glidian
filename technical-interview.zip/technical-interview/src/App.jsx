import { useEffect, useState } from "react";

import * as api from "./api";
import GroupSelect from "./GroupSelect";
import UsersList from "./UsersList";
import "./App.css";

export default function App() {
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const headings = ["username", "activated"];

  const onGroupChange = (val) => {
    api.listUsers(val).then(setUsers);
  }
  

  useEffect(() => {
    api.listGroups().then(setGroups);
  }, []);

  return (
    <div className="App">
      <GroupSelect
        groups={groups}
        onChange={(val) => onGroupChange(val)}
      />
      <UsersList caption="Users" users={users} heading={headings}/>
    </div>
  );
}
