/****************************************************************************************
 * CREATE YOUR USER INTERFACE HERE
 ****************************************************************************************/
import React from "react";
import "./UsersList.css";
import { activated } from "./api";


export default function UsersList(props) {
  const { users = [], heading = [] } = props;
  let targets = {};

  const userListHeader = (items) => {
    return (
      <div
        key="userListHeader"
        name="userListHeader"
        className="user-list-header"
      >
        {userListHeaderCell(items)}
      </div>
    );
  };

  const userListHeaderCell = (items) => {
    const cells = [];

    for (let i = 0; i < items.length; i++) {
      const cell = (
        <div key={items[i]} className="user-list-header-cell">
          {items[i]}
        </div>
      );
      cells.push(cell);
    }

    return cells;
  };

  const userListBody = (data) => {
    return (
      <div key="userListBody" name="userListBody" className="user-list-body">
        {userListBodyRow(data)}
      </div>
    );
  };

  const userListBodyRow = (items) => {
    const rows = [];

    for (let i = 0; i < items.length; i++) {
      const row = (
        <div
          key={items[i].id}
          name="userListRow"
          className="user-list-body-row"
        >
          {userListBodyRowCell(items[i])}
        </div>
      );

      rows.push(row);
    }

    return rows;
  };

  const userListBodyRowCell = (item) => {
    const cells = [];

    const username = (
      <div
        key="username"
        id="username"
        name="username"
        className="user-list-body-cell"
      >
        <input
          type="checkbox"
          id="cbUser"
          name="cbUser"
          value={item.id}
          onChange={(val) => handleChange(val)}
        />
        {item.name}
      </div>
    );

    const activate = (
      <div
        key="activate"
        id="activate"
        name="activate"
        className="user-list-body-cell"
      >
        {!item.isActivated ? <span>&#10006;</span> : <span>&#10004;</span>}
      </div>
    );

    cells.push(username);
    cells.push(activate);

    return cells;
  };

  const handleChange = (val) => {
    const target = val.target;
    const user = users.find(x => x.id === parseInt(target.value));

    targets[target.value] = user.isActivated ? false : true; 
  };

  const handleActivate = (e) => {
    activated(targets).then((response) => {
      if(response.status === 200) {
        window.location.reload();
        
      }
    });
  };

  return (
    <div
      key="userListContainer"
      name="userListContainer"
      className="user-list-container"
    >
      {userListHeader(heading)}
      {userListBody(users)}
      <div className="btn-activate">
        <input type="button" value="Activate" onClick={handleActivate} />
      </div>
    </div>
  );
}
